from endstone_antispam.antispam import AntiSpam

__all__ = ["AntiSpam"]